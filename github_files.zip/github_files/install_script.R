# Install the packages we need for the training

packagelist <- c("devtools", "tidyverse", "mangoTraining")
install.packages(packagelist)